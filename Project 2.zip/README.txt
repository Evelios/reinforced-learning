The program was written in Python 2.7
These files require the numpy module

All three tasks have been completed according to the assignment document

Task 3:
There is no tree pruning implemented as the program was consistantly delivering %80-90 accuract